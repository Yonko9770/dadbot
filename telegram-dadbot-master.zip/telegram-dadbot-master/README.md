# Telegram Dadbot
Shamelessly ripped off from: _Repository for Medium article about creating a Telegram bot in Python and deploying it on Heroku_

Check it out @ Medium: https://medium.com/python4you/creating-telegram-bot-and-deploying-it-on-heroku-471de1d96554
